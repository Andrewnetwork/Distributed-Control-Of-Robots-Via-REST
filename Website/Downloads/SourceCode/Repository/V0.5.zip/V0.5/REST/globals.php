<?php
// globals.php
// Andrew Ribeiro 
// November 22, 2009

define('SERVER_ADDR','YOUR SERVER IP HERE');
define('USER_NAME','DATABASE SERVER USERNAME HERE');
define('PASSWORD','DATABASE SERVER PASSWORD HERE');
define('DATABASE','DATABASE NAME HERE');
define('XML_HEADER','<?xml version="1.0"?>');
define('DROOT','DOCUMENT ROOT');

// DROOT: document root: EX: http://www.andrewribeiro.com/Testing/School/CS240/

?>