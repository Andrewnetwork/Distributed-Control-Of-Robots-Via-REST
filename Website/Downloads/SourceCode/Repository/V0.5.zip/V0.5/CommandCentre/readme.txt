readme.txt
Andrew Ribeiro 
December 06, 2009

** Bulding instructions **
+ You must link your project with the following dll's
 - odbc32.lib
 - odbccp32.lib
 - wininet.lib

** Platform information **
> Bult using Visual Studio 2008 
> Windows Vista 