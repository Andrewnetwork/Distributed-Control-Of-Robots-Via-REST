/** NSS_variable_functions.cpp
 * Andrew Ribeiro
 * November 24, 2009
**/

#include "NSS.h"
#include "constants.h"

#include <map>
#include <string>
#include <vector>
#include <iostream>
using namespace std; 

namespace comandrewribeiroremoterobot
{

}