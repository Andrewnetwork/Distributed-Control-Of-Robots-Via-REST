<?php
// globals.php
// Andrew Ribeiro 
// November 22, 2009

define('SERVER_ADDR','97.74.218.45');
define('USER_NAME','MiscAndrew');
define('PASSWORD','Csisfun1234');
define('DATABASE','MiscAndrew');
define('XML_HEADER','<?xml version="1.0"?>');
define('DROOT','http://www.andrewribeiro.com/Testing/School/CS240/');


?>