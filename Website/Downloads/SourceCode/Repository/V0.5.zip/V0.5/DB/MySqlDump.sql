-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Host: 97.74.218.45
-- Generation Time: Dec 06, 2009 at 02:11 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `MiscAndrew`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `command`
--

CREATE TABLE `command` (
  `commandID` int(10) unsigned NOT NULL auto_increment,
  `commandText` mediumtext NOT NULL,
  PRIMARY KEY  (`commandID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=375 ;


--
-- Stand-in structure for view `current_command_user`
--
CREATE TABLE `current_command_user` (
`username` varchar(30)
);
-- --------------------------------------------------------

--
-- Table structure for table `individual_owner`
--

CREATE TABLE `individual_owner` (
  `uid` int(10) unsigned NOT NULL,
  `ustream_embeded_code` text NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Stand-in structure for view `last_use`
--
CREATE TABLE `last_use` (
`userID` int(10) unsigned
,`time` timestamp
,`commandID` int(10) unsigned
,`completed` tinyint(1) unsigned
);
-- --------------------------------------------------------

--
-- Table structure for table `realtime_remote_commands`
--

CREATE TABLE `realtime_remote_commands` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL,
  `commandID` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=82 ;

--
-- Stand-in structure for view `recent_command`
--
CREATE TABLE `recent_command` (
`commandText` mediumtext
,`command` int(10) unsigned
);
-- --------------------------------------------------------

--
-- Table structure for table `use`
--

CREATE TABLE `use` (
  `userID` int(10) unsigned NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `commandID` int(10) unsigned NOT NULL,
  `completed` tinyint(1) unsigned default NULL,
  PRIMARY KEY  (`userID`,`commandID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) unsigned NOT NULL auto_increment,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY  (`uid`,`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Structure for view `current_command_user`
--
DROP TABLE IF EXISTS `current_command_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`MiscAndrew`@`%` SQL SECURITY DEFINER VIEW `MiscAndrew`.`current_command_user` AS select `MiscAndrew`.`user`.`username` AS `username` from `MiscAndrew`.`user` where `MiscAndrew`.`user`.`uid` in (select `MiscAndrew`.`use`.`userID` AS `userID` from `MiscAndrew`.`use` where `MiscAndrew`.`use`.`commandID` in (select `recent_command`.`command` AS `command` from `MiscAndrew`.`recent_command`));

-- --------------------------------------------------------

--
-- Structure for view `last_use`
--
DROP TABLE IF EXISTS `last_use`;

CREATE ALGORITHM=UNDEFINED DEFINER=`MiscAndrew`@`%` SQL SECURITY DEFINER VIEW `MiscAndrew`.`last_use` AS select `MiscAndrew`.`use`.`userID` AS `userID`,`MiscAndrew`.`use`.`time` AS `time`,`MiscAndrew`.`use`.`commandID` AS `commandID`,`MiscAndrew`.`use`.`completed` AS `completed` from `MiscAndrew`.`use` where `MiscAndrew`.`use`.`commandID` in (select max(`MiscAndrew`.`use`.`commandID`) AS `MAX(``commandID``)` from `MiscAndrew`.`use` where (`MiscAndrew`.`use`.`completed` = 1));

-- --------------------------------------------------------

--
-- Structure for view `recent_command`
--
DROP TABLE IF EXISTS `recent_command`;

CREATE ALGORITHM=UNDEFINED DEFINER=`MiscAndrew`@`%` SQL SECURITY DEFINER VIEW `MiscAndrew`.`recent_command` AS select `MiscAndrew`.`command`.`commandText` AS `commandText`,min(`MiscAndrew`.`command`.`commandID`) AS `command` from `MiscAndrew`.`command`;
