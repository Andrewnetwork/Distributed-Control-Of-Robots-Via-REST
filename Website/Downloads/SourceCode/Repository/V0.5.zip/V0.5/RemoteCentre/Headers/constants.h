/** constants.h
 * Andrew Ribeiro 
 * November 21, 2009 | December 06, 2009
**/

#pragma once

#include <string>
using std::string;

namespace comandrewribeiroremote
{
	const string REST_ROOT_URL = "http://www.andrewribeiro.com";
	const string REST_API_URL = "/Testing/School/CS240/REST/RealtimeRemote/RemoteAPI.php";
	const int DEFAULT_SPEED = 75;
	const int COMMAND_MAX_SIZE = 5;
}