/** RobotAPI.cpp
 * Andrew Ribeiro 
 * November 21, 2009 | December 06, 2009
**/

#pragma once

#include <string>
#include <vector>
#include <iostream>
using namespace std;

#include <windows.h>
#include <wininet.h>
#include <conio.h>

#include "web.h"
using namespace openutils;

#include "RobotAPI.h"
#include "constants.h"
#include "ErrorCodes.h"



namespace comandrewribeiroremote
{
	//************************** START ROBOT COMMANDS ********************
	void RobotAPI::connectToRobot()
	{
		// This is our interface with the NXT
		this->robotControl = new nxt_remote(); 

		// CHANGE THIS
		_cprintf("  SYSTEM: Starting NXT communication on port COM4... ");

		//initialize interface and check if initialization failed
	    if (this->robotControl->startcommunication("COM4")==0)
		{ 
			_cprintf("  SYSTEM: NXT communication failed.");

			//wait for keypress
			while (!_kbhit()); 
			return;
	    }
	}

	//********************************************************************

	//************************** START API COMMANDS *******************
	string RobotAPI::currentCommand()
	{
		try 
		{	
			WebForm wf;
			// the web server name is set
			wf.setHost(REST_ROOT_URL.c_str());
			// the script to be executed on the web server...
			wf.setScriptFile(REST_API_URL.c_str());

			// form variables are added to the request object
			wf.putVariable("username",this->username.c_str());
			wf.putVariable("password",this->password.c_str());
			wf.putVariable("fn","get_raw_command");
			
			wf.sendRequest();

			string response;

			if(wf.getResponse(response,COMMAND_MAX_SIZE)) 
			{
				// If no error 
				if(response.find("Error") == -1)
				{
					// The command has finished running. 
					if(response.size() > 0)
					{
						return response;
					}
					else
					{
						return "";
					}
				}
				else
				{
					// Recieved error code.
					if(response.compare(ErrorCodes::DB_ERROR) == 0)
					{
						cout<<endl<<"  SYSTEM: "<<ErrorCodes::getDiscription(ErrorCodes::DB_ERROR)<<endl;
					}
					else
					{
						cout<<"  SYSTEM: Unknown error"<<endl;
					}
					return "  SYSTEM: ERROR";
				}
			}
			else 
			{
				cout << "  SYSTEM: No response from server" << endl;
				return "ERROR";
			}	

		}
		catch(WebFormException ex) 
		{
			cout << ex.getMessage() << endl;
		}

		return "ERROR";
	}
	//************************** END API COMMANDS *******************

	//********************* START THREADS **********************
	DWORD WINAPI stopProcessingCommands(LPVOID hndle)
	{
		HANDLE * processCommandHandle = (HANDLE *)hndle;

		while(true)
		{

			// If user presses q stop processing commands.
			if(_getch() == 113)
			{
				// Kill the processing thread.
				TerminateThread(processCommandHandle,0); 
				cout<<endl<<"  SYSTEM: this command centre is now offline."<<endl;
				break;
			}
		}

		return 0;
	}


	DWORD WINAPI processCommands(LPVOID api)
	{
		cout<<"  SYSTEM: Starting to process commands."<<endl;
		RobotAPI * connection = (RobotAPI *)api;
		bool workingOnACommand = false, stopped = true; 
		string currentCommand,previousCommand;

		// Keep the thread alive forever(untill killed)
		while(true)
		{
			// Change this step here to improve performance. 
			previousCommand = connection->currentCommand();

			if(previousCommand.compare("1") == 0)
			{
				//Move forward 
				cout<<"  SYSTEM: FORWARD"<<endl;

				// Turn the motors on
				connection->getRobotControl()->NXT_motoron[0]=1;
				connection->getRobotControl()->NXT_motoron[2]=1;
		
				//Setting the motors power/velocity
				connection->getRobotControl()->NXT_motorval[0] = DEFAULT_SPEED;
				connection->getRobotControl()->NXT_motorval[2] = DEFAULT_SPEED;
				
			}
			else if(previousCommand.compare("2") == 0)
			{
				//Turn Left
				cout<<"  SYSTEM: LEFT"<<endl;

				connection->getRobotControl()->NXT_motoron[0]=1;

				// Turn the motors on
				connection->getRobotControl()->NXT_motoron[0]=1;
				connection->getRobotControl()->NXT_motoron[2]=0;
		
				//Setting the motors power/velocity
				connection->getRobotControl()->NXT_motorval[0] = DEFAULT_SPEED;
				connection->getRobotControl()->NXT_motorval[2] = 0;

			}
			else if(previousCommand.compare("3") == 0)
			{
				//Turn Right
				cout<<"  SYSTEM: RIGHT"<<endl;

				// Turn the motors on
				connection->getRobotControl()->NXT_motoron[0]=0;
				connection->getRobotControl()->NXT_motoron[2]=1;
		
				//Setting the motors power/velocity
				connection->getRobotControl()->NXT_motorval[0] = 0;
				connection->getRobotControl()->NXT_motorval[2] = DEFAULT_SPEED;

			}
			else if(previousCommand.compare("4") == 0)
			{
				//Go back
				cout<<"  SYSTEM: BACK"<<endl;

				// Turn the motors on
				connection->getRobotControl()->NXT_motoron[0]=1;
				connection->getRobotControl()->NXT_motoron[2]=1;
		
				//Setting the motors power/velocity
				connection->getRobotControl()->NXT_motorval[0] = -DEFAULT_SPEED;
				connection->getRobotControl()->NXT_motorval[2] = -DEFAULT_SPEED;
			}

			while(true)
			{
				currentCommand = connection->currentCommand();
				// If there is a command, execute it. 
				if(currentCommand.size() != 0)
				{
					// If there is not a new command, continue looping (i.e. continue doing the same command)
					if(previousCommand.compare(currentCommand) == 0)
					{
						// Still working on a command, keep waiting for no commands
						continue; 
					}
					break;
				}
				else
				{
					if(!stopped)
					{
						cout<<"  SYSTEM: STOP"<<endl;

						// No commands, stop the robot
						previousCommand = "";
						connection->getRobotControl()->NXT_motoron[0]=0;
						connection->getRobotControl()->NXT_motoron[2]=0;

						//Setting the motors power/velocity
						connection->getRobotControl()->NXT_motorval[0] = 0;
						connection->getRobotControl()->NXT_motorval[2] = 0;

						stopped = true;
					}
				}
			}

			stopped = false;
		}
	}

	//********************* END THREADS ************************


	//************************** START CLIENT FUNCTIONALITY **************
	void RobotAPI::startProcessing()
	{
		cout<<endl<<"  SYSTEM: Starting to process commands."<<endl;

		this->connectToRobot();

		cout<<endl
			<<"*************** SYSTEM LOG *******************"<<endl
			<<"* Press q to stop processing commands        *"<<endl;
		
		HANDLE listenForCommands,listenForQuit;
		DWORD dwGenericThread;

		// Keep fetching data from a database and making the robot move
		listenForCommands = CreateThread(NULL,0,processCommands,this,0,&dwGenericThread);

		// If the thread was not created.
		if(listenForCommands == NULL)
		{
			DWORD dwError = GetLastError();
			cout<<"  SYSTEM: "<<dwError<<endl ;
			return;
		}

		// Listen if the user wants to quit. 
		listenForQuit = CreateThread(NULL,0,stopProcessingCommands,listenForCommands,0,&dwGenericThread);

		// If the thread was not created.
		if(listenForQuit == NULL)
		{
			DWORD dwError = GetLastError();
			cout<<"  SYSTEM: "<<dwError<<endl ;
			return;
		}


		const HANDLE threads[] = {listenForCommands,listenForQuit}; 

		// Wait untill all threads have finished.
		WaitForMultipleObjects(2,threads,true,INFINITE);
	}



	//************************** END CLIENT FUNCTIONALITY **************

	//********************** START CONSTRUCTORS *************************
	RobotAPI::RobotAPI(string username, string password)
	{
		this->username = username;
		this->password = password;

		try 
		{	
			WebForm wf;
			// the web server name is set
			wf.setHost(REST_ROOT_URL.c_str());
			// the script to be executed on the web server...
			wf.setScriptFile(REST_API_URL.c_str());
			cout<<endl<<"  SYSTEM: Connecting to " << wf.getHost() << "..." << endl;

			// form variables are added to the request object
			wf.putVariable("username",username.c_str());
			wf.putVariable("password",password.c_str());
		
			cout << "  SYSTEM: Checking user credentials..." << endl;
			// data is encoded and send to the server script
			// for processing
			wf.sendRequest();

			// reading back any response	
			string response;

			if(wf.getResponse(response,50)) 
			{
				if(response.size() == 0)
				{
					// User credentials are good.
					cout<<"  SYSTEM: Login credentials confirmed"<<endl
						<<"  SYSTEM: This system is now a Command Centere"<<endl<<endl;
					validLogin = true;
				}
				else
				{
					validLogin = false;
					if(response.compare(ErrorCodes::INVALID_LOGIN) == 0)
					{
						cout<<endl<<"  SYSTEM: "<<ErrorCodes::getDiscription(ErrorCodes::INVALID_LOGIN)<<endl;
					}
					else
					{
						cout<<"  SYSTEM: Unknown error"<<endl;
					}
				}
			}
			else 
			{
				cout << "  SYSTEM: No response from server" << endl;
			}	

		}
		catch(WebFormException ex) 
		{
			cout << ex.getMessage() << endl;
		}

	}

	RobotAPI::RobotAPI(){}
	//********************** END CONSTRUCTORS ***************************
}