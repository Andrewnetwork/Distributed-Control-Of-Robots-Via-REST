/** 
 * RemoteCentre.cpp
 * Andrew Ribeiro 
 * December 6, 2009
**/

#include <string>
#include <vector>
#include <iostream>
using namespace std;

#include <windows.h>
#include <wininet.h>
#include <conio.h>

#include "web.h"
using namespace openutils;

#include "RobotAPI.h"
using namespace comandrewribeiroremote;

int main() 
{
	cout<<"*************** REMOTE CENTERE *****************"<<endl
		<<"* Welcome to the remote centere. Here is where *"<<endl
		<<"* bluetooth commands are issued to a NXT robot.*"<<endl
		<<"* This particular version is built for use on  *"<<endl
		<<"* a windows based PC, however the architecture *"<<endl
		<<"* supports manny client types... enjoy         *"<<endl
		<<"*                                              *"<<endl
		<<"* Created by: Andrew Ribeiro                   *"<<endl
		<<"* Version: V0.5                                *"<<endl
		<<"************************************************"<<endl<<endl;

	bool loopCondition = true;
	RobotAPI sysAPI;

	while(loopCondition)
	{
		string username,password;
		char ch;

		cout<<"********* API Connection ************"<<endl
			<<"* Username: ";

		getline(cin,username);

		cout<<"* Password: ";
		
		ch = _getch();

		// While the user does not press enter. 
		while(ch != 13)
		{
			password.push_back(ch);
			cout << '*';
			ch = _getch();
		}

		cout<<endl<<"*************************************"<<endl;

		RobotAPI api(username,password);

		// If it is not a valid client, ask for password again.
		if(api.isValidClient())
		{
			// Client is valid, go to menu.
			loopCondition = false;
			sysAPI = api;
		}
	}
	
	do
	{
		int choice;

		cout<<endl
			<<endl
			<<"*************** MAIN MENU **************"<<endl
			<<" 1.) Start command processing"<<endl<<endl
			<<" Choice(1): ";

		cin>>choice;

		if(choice == 1)
		{
			sysAPI.startProcessing();
		}
		
	}while(true);


	return 0;
}
